# Menu Title: Create Item Sets from Queries
# Needs Case: true
# Needs Selected Items: false

script_directory = File.dirname(__FILE__)
require File.join(script_directory,"Nx.jar")
java_import "com.nuix.nx.NuixConnection"
java_import "com.nuix.nx.LookAndFeelHelper"
java_import "com.nuix.nx.dialogs.ChoiceDialog"
java_import "com.nuix.nx.dialogs.CustomDialog"
java_import "com.nuix.nx.dialogs.TabbedCustomDialog"
java_import "com.nuix.nx.dialogs.CommonDialogs"
java_import "com.nuix.nx.dialogs.ProgressDialog"
java_import "com.nuix.nx.dialogs.ProcessingStatusDialog"
java_import "com.nuix.nx.digest.DigestHelper"
java_import "com.nuix.nx.controls.models.Choice"

LookAndFeelHelper.setWindowsIfMetal
NuixConnection.setUtilities($utilities)
NuixConnection.setCurrentNuixVersion(NUIX_VERSION)

deduplication_choices = [
	"MD5",
	"MD5 Per Custodian",
	"MD5 Ranked Custodian",
	"None",
]

deduplicate_by_choices = [
	"INDIVIDUAL",
	"FAMILY"
]

dialog = TabbedCustomDialog.new("Create Item Sets from Queries")
input_tab = dialog.addTab("input_tab","Input")
input_tab.appendCsvTable("input_data",["ItemSetName","Query"])

item_set_tab = dialog.addTab("item_set_tab","Item Set Options")
item_set_tab.appendComboBox("deduplication","Deduplication Method",deduplication_choices)
item_set_tab.appendComboBox("deduplicate_by","Deduplicate By",deduplicate_by_choices)
item_set_tab.appendHeader("Custodian Ranking")
item_set_tab.appendChoiceTable("custodian_ranking","Custodian Ranking",$current_case.getAllCustodians.to_a.map{|c|Choice.new(c)})

dialog.validateBeforeClosing do |values|
	# Check the input data user provided (ItemSetName and Query)
	warned_about_blank_query = false
	input_data_passed = true
	values["input_data"].each_with_index do |input_record,input_record_index|
		# If ItemSetName is empty, tell user they need to fix this
		if input_record["ItemSetName"].nil? || input_record["ItemSetName"].strip.empty?
			CommonDialogs.showWarning("Please provide a value for 'ItemSetName' on row #{input_record_index+1}.")
			input_data_passed = false
			break
		end

		# If Query is blank, warn user once, allowing them to cancel and fix or proceed with the operation
		if input_record["Query"].nil? || input_record["Query"].strip.empty?
			if !warned_about_blank_query
				if CommonDialogs.getConfirmation("The value for 'Query' on row #{input_record_index+1} is empty, this will yield all items in the case, proceed?") == false
					input_data_passed = false
					break
				else
					warned_about_blank_query = true
				end
			end
		end
	end
	next false if !input_data_passed

	# Make sure custodians are selected if were doing custodian ranked dedupe
	if values["deduplication"] == "MD5 Per Custodian" || values["deduplication"] == "MD5 Ranked Custodian"
		if values["custodian_ranking"].size == 0
			CommonDialogs.showWarning("Please select at least one custodian since you are using '#{deduplication}'.")
			next false
		end
	end

	# Notify user that we need to close all tabs to help prevent item set operations from having issues
	if NuixConnection.getCurrentNuixVersion.isAtLeast("6.2")
		# Get user confirmation about closing all workbench tabs
		if CommonDialogs.getConfirmation("The script needs to close all workbench tabs, proceed?") == false
			next false
		end
	end

	next true
end

dialog.display
if dialog.getDialogResult == true
	values = dialog.toMap
	input_data = values["input_data"]
	item_set_settings = {
		"deduplication" => values["deduplication"],
		"deduplicateBy" => values["deduplicate_by"],
		"custodianRanking" => values["custodian_ranking"],
	}

	$window.closeAllTabs

	ProgressDialog.forBlock do |pd|
		pd.setTitle("Create Item Sets from Queries")

		pd.setMainProgress(0,input_data.size)
		input_data.each_with_index do |record,record_index|
			break if pd.abortWasRequested

			pd.logMessage("===== #{record_index+1}/#{input_data.size} =====")

			pd.setMainProgress(record_index+1)

			item_set_name = record["ItemSetName"]
			query = record["Query"]

			pd.logMessage("Item Set Name: #{item_set_name}")
			pd.logMessage("Query: #{query}")

			pd.setMainStatusAndLogIt("Searching...")
			items = $current_case.search(query)
			pd.logMessage("Found #{items.size} items")

			if items.size < 1
				pd.logMessage("Query yielded no items, skipping step to create or add to item set")
			else
				pd.setMainStatus("Resolving item set...")
				item_set = $current_case.findItemSetByName(item_set_name)
				if item_set.nil?
					pd.logMessage("Creating new item set...")
					item_set = $current_case.createItemSet(item_set_name,item_set_settings)
				else
					pd.logMessage("Using existing item set...")
				end

				pd.setMainStatusAndLogIt("Adding items to item set...")
				item_set.addItems(items)
			end
		end

		if !pd.abortWasRequested
			pd.setCompleted
			$window.openTab("workbench",{:search => "has-item-set:1"})
		else
			pd.logMessage("User Aborted")
		end
	end
end